--[[
	Bagnon_Tooltips Localization
		Traditional Chinse - 20071117 by matini< yiting.jheng <at> gmail <dot> com
--]]
if GetLocale() ~= "zhTW" then return end

BAGNON_NUM_BAGS = '背包: %d'
BAGNON_NUM_BANK = '銀行: %d'
BAGNON_EQUIPPED = '已裝備'