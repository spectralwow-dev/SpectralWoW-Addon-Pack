--Lua functions
--WoW API / Variables
local SlashCmdList = SlashCmdList
-- GLOBALS: SLASH_RELOADUI1, SLASH_RELOADUI2

SLASH_RELOADUI1 = "/rl"
SLASH_RELOADUI2 = "/reloadui"
SlashCmdList.RELOADUI = ReloadUI
